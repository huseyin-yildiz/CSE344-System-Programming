
# include <fcntl.h>
# include <errno.h>
# include <stdio.h>


int dup(int oldfd);