The test directory is used for testing. At first it had some large files. But I deleted the large files. Because the zip file size would be large. You can test the program with that test directory. 
Thanks. 
